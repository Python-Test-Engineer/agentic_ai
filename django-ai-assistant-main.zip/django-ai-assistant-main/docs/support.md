# Support

If you have any questions or need help, feel free to create a thread on [GitHub Discussions](https://github.com/vintasoftware/django-ai-assistant/discussions).

In case you're facing a bug, please [check existing issues](https://github.com/vintasoftware/django-ai-assistant/issues) and create a new one if needed.

## Commercial Support

[![alt text](https://avatars2.githubusercontent.com/u/5529080?s=80&v=4 "Vinta Logo")](https://www.vintasoftware.com/)

This is an open-source project maintained by [Vinta Software](https://www.vinta.com.br/). We are always looking for exciting work! If you need any commercial support, feel free to get in touch: contact@vinta.com.br
