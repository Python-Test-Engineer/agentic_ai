# django_ai_assistant.helpers.assistants

::: django_ai_assistant.helpers.assistants
    options:
        show_bases: false
        filters:
            - "!__init_subclass__"
