# django_ai_assistant.models

::: django_ai_assistant.models
    options:
        show_bases: true
