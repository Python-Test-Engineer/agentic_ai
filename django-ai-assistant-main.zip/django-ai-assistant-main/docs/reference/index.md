# Reference

This is the reference documentation for the Django AI Assistant library.

## Modules

- [django_ai_assistant.helpers.use_cases](use-cases-ref.md)
- [django_ai_assistant.helpers.assistants](assistants-ref.md)
- [django_ai_assistant.models](models-ref.md)
